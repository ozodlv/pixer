/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ["207.154.221.44"], // Add your image domain(s) here
      },
    distDir: 'build',
    output: 'export',
    images :{
        unoptimized: true
    }
}

module.exports = nextConfig
