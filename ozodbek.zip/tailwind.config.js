/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      screens: {
        'sm': {'max': '320px'},
        'md': {'max': '768px'},
        'lg': {'max': '1024px'},
        'xl': {'max': '1280px'},
      }, 
      backgroundImage: {
        'hero-pattern': "url('./src/app/assets/bgrame.png')",
      } ,
      colors: {
        customColor: "#6C5FBC",
        cGray: "#676767",
        cBlack: "#201F1F",
        blackBlue: "#323142",
        lightGray: '#C5BFED'
      },
      container: {
        
        padding: {
        
          DEFAULT: "2rem",
          md: "1rem",
        },
        center: true,
      },
      boxShadow: {
        'custom': '6.84842px 82.18102px 41.09051px 0px rgba(229, 229, 229, 0.70)',
      },
    },
  },
  plugins: [],
}
