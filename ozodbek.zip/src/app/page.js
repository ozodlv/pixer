import Image from 'next/image'
import Intro from './components/Intro'
import Statics from './components/staticts'
import Mobile from './components/mobile'
import Restorant from './components/Restorant'
import Purchses from './components/Purchses'
import Discount from './components/Discount'

export default function Home() {
  return (
    <main>
       <Intro/>
       <Statics/>
       <Mobile/>
       <Restorant/>
       <Purchses/>
       <Discount/>
    </main>
  )
}
