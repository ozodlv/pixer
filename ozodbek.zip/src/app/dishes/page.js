"use client";
import React, { useEffect, useState } from "react";
import axios from "axios";
import Card from "../components/Card";
import Loader from "../components/Loader";
import Accordion from "../components/Accordion";
const accordions = [
  {
    title: "How long does delivery take?",
    text: "You Can Get Information By Contacting Our Support Team Have 24/7 Service.What’s The Difference Between Free And Paid Plan ?",
  },
  {
    title: "How Does It Work ?",
    text: "You Can Get Information By Contacting Our Support Team Have 24/7 Service.What’s The Difference Between Free And Paid Plan ?",
  },
  {
    title: "How does your food delivery service work?",
    text: "You Can Get Information By Contacting Our Support Team Have 24/7 Service.What’s The Difference Between Free And Paid Plan ?",
  },
  {
    title: "What payment options do you accept?",
    text: "You Can Get Information By Contacting Our Support Team Have 24/7 Service.What’s The Difference Between Free And Paid Plan ?",
  },
  {
    title: "Do you offer discounts or promotions?",
    text: "You Can Get Information By Contacting Our Support Team Have 24/7 Service.What’s The Difference Between Free And Paid Plan ?",
  },
];
function Dishes() {
  const [dishes, setDishes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ page: 1 });

  useEffect(() => {
    async function fetchData() {
      try {
        const response = await axios.get(
          `http://207.154.221.44:4002/api/dishes?page=${form.page}&${
            form.query ? `name=${form.query}` : ""
          }`
        );
        setDishes(response.data.data.data);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching data:", error);
        setLoading(false);
      }
    }

    fetchData();
  }, [form]);
  const handlechange = (e) => {
    setForm((pre) => ({
      ...form,
      [e.target.name]: e.target.value,
    }));
  };

  const incrementPage = () => {
    setForm({ ...form, page: form.page + 1 });
  };

  const decrementPage = () => {
    if (form.page > 1) {
      setForm({ ...form, page: form.page - 1 });
    }
  };
console.log(form.query);
console.log(`http://207.154.221.44:4002/api/dishes?page=${form.page}${
  form.query ? `&name=${form.query}` : ""
}`);
  return (
    <main>
      <section className="container">
        <label className="mx-auto  my-5 block">
          <input 
          onKeyUp={handlechange}
            className="m-auto block py-2 px-2 rounded-xl border-2 "
            type="text"
            name="query"
            placeholder="Search..."
          />
        </label>
        <div>
          {loading ? (
            <Loader />
          ) : (
            <ul className="flex items-center  flex-wrap  gap-10 md:gap-5 justify-center">
              {dishes.map((dish) => (
                <Card data={dish} />
              ))}
            </ul>
          )}
        </div>
        <div className="flex items-center  gap-3 justify-center my-9">
          <button
            className="border-2  px-4 py-2 rounded-xl border-blackBlue w-[100px] text-blackBlue"
            onClick={decrementPage}
          >
            Previous
          </button>
          <button
            className="border-2  px-4 py-2 rounded-xl border-blackBlue w-[100px] text-blackBlue"
            onClick={incrementPage}
          >
            Next
          </button>
        </div>
      </section>
      <section className="container  my-18">
        <div className="flex items-center justify-center ">
          <h1 className="text-3xl font-semibold w-[250px] text-center m-15 ">
            Frequently Asked
            <span className="text-customColor">Questions</span>
          </h1>
        </div>
        <div className=" max-w-5xl mx-auto">
          {accordions.map((e, i) => (
            <Accordion key={i} data={e} />
          ))}
        </div>
      </section>
    </main>
  );
}

export default Dishes;
