"use client";
import Image from "next/image";
import React from "react";

import { useEffect } from "react";
import { useState } from "react";

function Cart() {
  const [orders, setOrders] = useState([]);
  const [total, setTotal] = useState(0); 

  useEffect(() => {
    const calculateTotalPrice = () => {
      const subtotal = orders.reduce(
        (acc, order) => acc + order.price * order.quantity,
        0
      );
      
      const total = (subtotal).toFixed(2); // Round to two decimal places
      return total;
    };
  
    setTotal(calculateTotalPrice());
  }, [orders]);
  
  
  useEffect(() => {
    const storedOrders = JSON.parse(window.localStorage.getItem("orders"));
    if (Array.isArray(storedOrders)) {
      setOrders(storedOrders);
    } else {
      setOrders([]);
      window.localStorage.setItem("orders", JSON.stringify(orders));
    }
  }, []);
  const removeFromCart = (id) => {
    setOrders((prevOrders) => prevOrders.filter((order) => order.id !== id));
    window.localStorage.setItem("orders", JSON.stringify(orders));
  };

  const decrementQuantity = (id) => {
    const targetOrder = orders.find((order) => order.id === id);

    if (targetOrder) {
      if (targetOrder.quantity === 1) {
        removeFromCart(id);
      } else {
        setOrders((prevOrders) =>
          prevOrders.map((order) =>
            order.id === id ? { ...order, quantity: order.quantity - 1 } : order
          )
        );
        window.localStorage.setItem("orders", JSON.stringify(orders));
      }
    }
  };

  const incrementQuantity = (id) => {
    setOrders((prevOrders) =>
      prevOrders.map((order) =>
        order.id === id ? { ...order, quantity: order.quantity + 1 } : order
      )
    );
    window.localStorage.setItem("orders", JSON.stringify(orders));
  };
  return (
    <main>
      <section className="container">
        <ul className="flex flex-col gap-3 ">
          {orders.map((el, i) => (
            <li  key={i} className="flex  justify-between  m-auto  w-[60%] md:w-[90%] p-2 bg-white boxShadow rounded-xl my-2 ">
              <div className="flex gap-6 md:gap-2">
                <Image
                  src={`http://207.154.221.44:4002/${el?.image}`}
                  width={90}
                  height={90}
                  alt={el.name}
                />
                <div className="flex flex-col gap-3 justify-center ">
                  <h2 className="text-blackBlue text-2xl md:text-lg font-semibold  md:font-normal" >{el.name}</h2>
                  <p className="text-blackBlue text-xl md:text-sm font-semibold "  >${el.price}</p>
                </div>
              </div>
              <div className="flex flex-col items-center justify-center">
                <div className="flex items-center gap-3 text-blackBlue text-xl md:text:lg font-semibold  ">
                  <button
                    onClick={() => decrementQuantity(el.id)}
                    className="border-2 flex items-center justify-center border-blackBlue w-[31px] h-[28px] text-blackBlue text-xl font-semibold   text-center rounded-lg"
                  >
                    -
                  </button>
                  {el.quantity}
                  <button
                    onClick={() => incrementQuantity(el.id)}
                    className="border-2 flex items-center justify-center border-blackBlue bg-blackBlue text-white font-semibold w-[31px] h-[28px]  rounded-lg"
                  >
                    +
                  </button>
                </div>
                <span className="text-blackBlue text-xl md:text-lg font-semibold " >${(el.price * el.quantity).toFixed(2)}</span>
              </div>
            </li>
          ))}
        </ul>
        <ul className="w-[60%] md:w-[90%]  m-auto my-14 " >
          <li className="flex justify-between p-2  border-dashed border-b-2 border-cGray" ><h6 className="text-cGray text-xl " >Subtotal</h6> <span className="text-blackBlue text-lg " >${total}</span></li>
          <li className="flex justify-between p-2  border-dashed border-b-2 border-cGray" ><h6 className="text-cGray text-xl " >Delivery</h6> <span className="text-blackBlue text-lg " >{orders.length ? '$3.99': '$0'}</span></li>
          <li className="flex justify-between p-2  " ><h6 className="text-blackBlue font-semibold text-xl " >Total</h6> <span className="text-blackBlue text-lg " >${total + 4}</span></li>
          <button className="bg-customColor text-white px-6 py-3  w-full my-12  rounded-xl" >Review Payment</button>
        </ul>
      </section>
    </main>
  );
}

export default Cart;
