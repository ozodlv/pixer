"use client";
import Link from "next/link";
import React, { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { Cart, Logo } from "../icons/icons";

function Header() {
  const pathname = usePathname();
  const [isHeaderShrunk, setIsHeaderShrunk] = useState(false);
  const [bar, setBar] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsHeaderShrunk(true);
      } else {
        setIsHeaderShrunk(false);
      }
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const toggleMenu = () => {
    if (window.innerWidth <= 790) {
      setBar(!bar);
    }
  };

  const getMenuClassNames = () => {
    const baseClasses =
      "flex items-center z-30  justify-between w-full transition-all ease-in-out duration-1000 md:absolute md:top-0 md:right-0 md:justify-center md:flex-col translate-x-0 md:bg-white md:h-[100vh]";
    return bar
      ? `${baseClasses} md:translate-x-0   `
      : ` md:translate-x-[100%] md:hidden  ${baseClasses}`;
  };

  return (
    <header
      className={`transition-all ease-in-out ${
        isHeaderShrunk ? "fixed bg-white top-0 w-full" : ""
      } mx-auto border-b-2 border-solid border-lightGray p-2 px-6 z-30 bg-white top-0`}
    >
      <div className="flex items-center md:justify-between duration-1000      transition ease-in-out">
        <Logo />

        <nav onClick={() => toggleMenu()} className={getMenuClassNames()}>
          <div className="flex items-center md:flex-col">
            <Link
              className={`${
                pathname === "/" ? "text-customColor" : "text-cGray"
              } font-semibold py-3 px-6`}
              href="/"
            >
              Home
            </Link>
            <Link
              className={`${
                pathname === "/dishes" ? "text-customColor" : "text-cGray"
              } font-semibold py-3 px-6`}
              href="/dishes"
            >
              Dishes
            </Link>
          </div>

          <div className="flex items-center md:flex-col">
            <Link
              className={`${
                pathname === "/cart" ? "text-customColor" : "text-cGray"
              } font-semibold py-3 px-6`}
              href="/cart"
            >
              <Cart />
            </Link>
            <Link
              className={`${
                pathname === "/login" ? "text-customColor" : "text-cGray"
              } font-semibold py-3 px-6`}
              href="/login"
            >
              Login
            </Link>
            <Link
              className="bg-customColor text-white px-6 py-3 rounded-2xl"
              href="/register"
            >
              Sign up
            </Link>
          </div>
        </nav>

        <button className="invisible md:visible md:z-30" onClick={toggleMenu}>
          {bar ? (
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          ) : (
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
          )}
        </button>
      </div>
    </header>
  );
}

export default Header;
