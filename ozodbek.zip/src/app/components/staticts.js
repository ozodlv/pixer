import React from "react";
const data = [
  {
    num: "10K+",
    text: `Satisfied Costumers
          All Great Over The World `,
  },
  {
    num: "4M",
    text: `Healthy Dishes Sold Including Milk Shakes Smooth`,
  },
  {
    num: "99.99%",
    text: `Reliable Customer SupportWe Provide Great Experiences`,
  },
];
function Statics() {
  return (
    <section className="bg-customColor">
      <div className="flex md:flex-col md:items-center p-16 container justify-around ">
        {data.map((e) => (
          <div className="flex flex-col items-center justify-center gap-4 max-w-[240px]">
            <h5 className="text-white text-6xl md:text-3xl font-semibold">{e.num}</h5>
            <p className="text-lightGray md:text-sm text-center">{e.text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export default Statics;
