"use client";
import { useState } from "react";

function Accordion({ data }) {
  const [isOpen, setIsOpen] = useState(false);

  const toggleAccordion = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className="border-b-2  ">
      <div
        className="flex items-center justify-between p-4 cursor-pointer transition-all duration-300 ease-in-out"
        onClick={toggleAccordion}
        style={{ backgroundColor: isOpen ? "#f0f0f0" : "transparent" }}
      >
        <h2 className="text-lg font-semibold">{data.title}</h2>
        {isOpen ? (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="31"
            height="31"
            viewBox="0 0 31 31"
            fill="none"
          >
            <circle
              cx="15.7456"
              cy="15.856"
              r="14.5023"
              fill="#6C5FBC"
              stroke="#6C5FBC"
              strokeWidth="1.11556"
            />
            <rect
              x="10.168"
              y="15.8564"
              width="10.5978"
              height="1.11556"
              fill="white"
            />
          </svg>
        ) : (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="31"
            height="31"
            viewBox="0 0 31 31"
            fill="none"
          >
            <circle
              cx="15.7452"
              cy="15.4112"
              r="14.5023"
              fill="#6C5FBC"
              stroke="#6C5FBC"
              strokeWidth="1.11556"
            />
            <rect
              x="10.1675"
              y="15.4111"
              width="10.5978"
              height="1.11556"
              fill="white"
            />
            <rect
              x="14.9087"
              y="21.2681"
              width="10.5978"
              height="1.11556"
              transform="rotate(-90 14.9087 21.2681)"
              fill="white"
            />
          </svg>
        )}
      </div>
      <div
        className={`p-4 transition-all duration-300 ease-in-out ${
          isOpen ? "block" : "hidden"
        }`}
      >
        <p className="text-gray-700">{data.text}</p>
      </div>
    </div>
  );
}

export default Accordion;
