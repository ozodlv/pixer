"use client"
import React, { useEffect, useState } from "react";
import CustomImage from "./image";
import { Rate } from "../icons/icons";

function Card({ data }) {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    const storedOrders = JSON.parse(window.localStorage.getItem("orders"));
    if (Array.isArray(storedOrders)) {
      setOrders(storedOrders);
    }else{
      setOrders([])
      window.localStorage.setItem("orders", JSON.stringify(orders));
    }
  }, []); 

  const toCart = async (data) => {
    const orders = JSON.parse(
      window.localStorage.getItem("orders")
        ? window.localStorage.getItem("orders")
        : []
    );
    const existOrder = orders.find((order) => order.id === data.id);
    if (existOrder) {
      const ind = orders.findIndex((pre) => pre.id === existOrder.id);

      orders.splice(ind, 1);

      window.localStorage.setItem("orders", JSON.stringify(orders));
    } else {
      const newData = {
        ...data,
        quantity: 1,
      };
      orders.push(newData);
      window.localStorage.setItem("orders", JSON.stringify(orders));
    }
  };
  return (
    <div className="  boxShadow w-[220px] md:w-[150px] min-h-[350px] md:min-h-[260px] flex flex-col bg-white   rounded-2xl p-4  gap-1">
      <CustomImage product={data} />
      <span className="bg-[#F7EDD0] text-[#DAA31A] w-fit py-[2px] px-2 md:px-1 rounded-lg md:rounded-md text-sm md:text-xs ">
        {data.type}
      </span>
      <h2 className="text-blackBlue text-[23px]  md:text-[18px] font-bold">{data.name}</h2>
      <div className="flex text-lightGray md:text-xs items-center ">
        {data.time} min · <Rate /> {data.mark}
      </div>
      <div className="flex items-center justify-between">
        <span className="text-[25px] md:text-[18px] text-blackBlue font-semibold">
          {data.price}
        </span>
        <button
          onClick={() => toCart(data)}
          className="w-[40px] md:w-[25px] h-[35px] md:h-[20px] flex items-center justify-center text-white bg-blackBlue font-bold md:font-semibold text-2xl md:text-xl rounded-xl md:rounded-md"
        >
          +
        </button>
      </div>
    </div>
  );
}

export default Card;
