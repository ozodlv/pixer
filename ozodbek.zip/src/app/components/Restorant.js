import Image from "next/image";
import React from "react";
import image from "../assets/restorant.png";
import { Arrow, Bookmark, Rate } from "../icons/icons";
import axios from "axios";
import Card from "./Card";
import Link from "next/link";
async function Restorant() {
  return axios
    .get("http://207.154.221.44:4002/api/dishes?page_size=5")
    .then((e) => {
      return (
        <section className="container     border-b-2 py-16">
          <div className="flex md:w-full w-[90%] mx-auto items-center flex-col my-12 boxShadow bg-white  rounded-xl    ">
            <Image src={image} className="w-full" alt="Retorant image" />
            <div className="flex items-center justify-between w-full p-5 md:p-2">
              <h4 className="text-blackBlue text-2xl md:text-xl font-bold">
                The Chicken King
              </h4>
              <span className="flex items-center md:text-sm text-lightGray ">
                24min • <Rate /> 4.8
              </span>
              <button>
                <Bookmark />
              </button>
            </div>
          </div>
          <div className="relative   ">
            <h1 className=" text-center text-5xl md:text-3xl font-semibold text-blackBlue  m-12  md:m-7 ">
              Our Top <span className="text-customColor">Dishes</span>
            </h1>
            <div className="flex flex-wrap md:gap-4 justify-center gap-8">
              {e.data.data.data?.map((el) => {
                return <Card data={el} />;
              })}
            </div>
            <Link
              href={"/dishes"}
              className="text-lightGray flex md:text-md items-center  absolute  z-10 right-2 bottom-[-70px]  "
            >
              View All <Arrow />{" "}
            </Link>
          </div>
        </section>
      );
    });
}

export default Restorant;
