import Image from "next/image";
import React from "react";
import image from "../assets/imag1.png";
function Discount() {
  return (
    <section>
      <div className="container my-16 ">
        <div className="flex flex-col gap-3 bg-customColor hero-pattern rounded-3xl p-12 md:p-6 my-3 relative md:items-center ">
          <h1 className="text-5xl md:text-3xl text-white  md:font-bold  font-extrabold">GET 50%</h1>
          <form className="bg-lightGray flex items-center  justify-between w-[500px] md:w-full  rounded-xl md:rounded-md p-2 md:p-1 ">
            <input
              type="text"
              className=" bg-transparent outline-none w-[70%]   placeholder:text-white md:placeholder:text-sm "
              placeholder=" Enter Your Email Address"
            />
            <button
              type="submit"
              className="w-fit   bg-customColor text-white px-6 md:p-2 py-3   rounded-xl text-center"
            >
              subscribe
            </button>
          </form>
          <div className="absolute flex inset-0  justify-end mr-16 md:mr-0 md:justify-center items-center">
            {" "}
            <Image
              className="absolute   bottom-[-50%] mx-auto w-[180px] md:w-[100px]  "
              alt="image"
              src={image}
            />
          </div>
        </div>
      </div>
    </section>
  );
}

export default Discount;
