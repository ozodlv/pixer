import React from "react";
import MiniCard from "./MiniCard";
import { Expense, Vocher } from "../icons/icons";

function Purchses() {
  return (
    <section className="container py-24 md:py-12 flex md:flex-col md:items-center    ">
      <div className="flex flex-col w-1/2 md:w-full gap-3 ">
        <h1 className="text-blackBlue text-5xl md:text-3xl md:text-center md:p-4 font-bold">
          Control Purchases Via{" "}
          <span className="text-customColor">Dashboard</span>
        </h1>
        <div className="flex flex-col gap-3">
          <MiniCard />
          <MiniCard />
          <MiniCard />
        </div>
      </div>
      <div className="flex flex-col bg-white rounded-3xl boxShadow p-12 md:p-4 w-[530px] md:w-full gap-3 ">
        <div className="flex justify-between p-2 ">
          <h4 className="text-4xl md:text-2xl font-semibold text-blackBlue">Purchases</h4>
          <select className="md:text-sm" >
            <option value="currentMonth"> This month</option>
          </select>
        </div>
        <div className="flex flex-col gap-5  md:w-full ">
          <div className="rounded-lg p-4 flex flex-col  gap-4 border-2 w-full relative">
            <div className="flex items-center gap-3 ">
              <span className="bg-lightGray  p-2 rounded-full">
                <Expense />
              </span>
              <div className="flex flex-col">
                <h1>Expense</h1>
                <p>Increased By 10%</p>
              </div>
              <h3 className="text-blackBlue font-semibold absolute right-3">$409.00</h3>
            </div>
            <div className="w-full bg-lightGray rounded-full h-2.5 ">
              <div
                className="bg-customColor h-2.5 rounded-full"
                style={{ width: "78%" }}
              ></div>
            </div>
          </div>
          <div className="rounded-lg p-4 flex flex-col  gap-4 border-2 w-full relative">
            <div className="flex items-center gap-3 ">
              <span className="bg-lightGray  p-2 rounded-full">
                <Vocher />
              </span>
              <div className="flex flex-col">
                <h1>Vocher Usage</h1>
                <p>Increased By 5%</p>
              </div>
              <h3 className="text-blackBlue font-semibold absolute right-3">$205.89</h3>
            </div>
            <div className="w-full bg-lightGray rounded-full h-2.5 ">
              <div
                className="bg-orange-600 h-2.5 rounded-full"
                style={{ width: "45%" }}
              ></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Purchses;
