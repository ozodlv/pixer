import Image from "next/image";
import React from "react";
import image from "../assets/mobile.png";
import { Arrow } from "../icons/icons";
function Mobile() {
  return (
    <section className="container">
      <div className="flex md:flex-col-reverse md:items-center md:p-5">
        <div className=" flex items-center  justify-center w-[50%]    " >
          <Image src={image} alt="Mobile image" className="max-h-[80%] object-contain"  />
        </div>
        <div className="flex flex-col w-[30%] md:w-full justify-center gap-14 md:items-center p-3 ">
          <h4 className="text-blackBlue font-bold  text-4xl md:text:2xl md:text-center " >Premium <span className="text-customColor" >Quality</span> For Your Health </h4>
          <ul className="md:flex md:items-center md:flex-col" >
            <li className="text-cGray list-disc" >
              Premium quality food is made with ingredients that are packed with
              essential vitamins, minerals.
            </li>
            <li className="text-cGray list-disc" >
              These foods promote overall wellness by support healthy digestion
              and boosting immunity
            </li>
          </ul>
          <button className="bg-customColor text-white px-6 py-3  flex items-center   rounded-2xl w-fit">
            Download <Arrow/>
          </button>
        </div>
      </div>
    </section>
  );
}

export default Mobile;
