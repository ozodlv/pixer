import React from "react";
import Image from "next/image";
import image from "../assets/imag1.png";
function MiniCard() {
  return (
    <div className="flex gap-2 boxShadow bg-white p-2 rounded-xl w-[340px] md:w-full relative  ">
      <Image src={image} alt="Image" />
      <div className="flex flex-col justify-center ">
        <h2 className="text-blackBlue text-lg font-semibold" >Chicken Hell</h2>
        <span className="text-blackBlue text-sm" >On The Way</span>
      </div>
      <span className="absolute text-lightGray right-2 text-sm font-semibold bottom-2 " >3:09 PM</span>
    </div>
  );
}

export default MiniCard;
