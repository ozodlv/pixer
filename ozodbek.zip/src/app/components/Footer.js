import React from "react";
import { Face, Inst, Liin, Logo, Twit } from "../icons/icons";

function Footer() {
  return (
    <section className="bg-[#EAEAEA]">
      <div className="container py-9 relative">
        <div className="flex py-6  md:py-3 border-b-2 border-cGray">
          <Logo />
        </div>
        <div className="flex justify-between py-7 md:py-4 ">
          <h3 className="text-lg md:text-sm text-cGray md:text-center ">
            © 2023 EATLY All Rights Reserved.
          </h3>
          <ul className=" flex  gap-4 md:absolute md:top-16 right-3">
            <li>
              <Inst />
            </li>
            <li>
              <Face />
            </li>
            <li>
              <Twit />
            </li>
            <li>
              <Liin />
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
}

export default Footer;
