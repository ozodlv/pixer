import React from "react";
import Image from "next/image";
import image from "../assets/IntroImage.png";
function Intro() {
  return (
    <section className="container ">
      <div className="flex items-center justify-between md:flex-col py-4 m-auto ">
        <div className="flex flex-col gap-7 justify-center md:items-center  w-[50%] md:w-full  pr-10 md:p-5 ">
          <span className="text-cGray  flex items-center gap-5 font-medium">
            {" "}
            <span className="bg-cGray block w-[60px] h-[2px]"></span>OVER 1000
            USERS
          </span>
          <h1 className="text-cBlack font-bold text-6xl md:text-4xl md:text-center">
            Enjoy Foods All Over The{" "}
            <span className="text-customColor">World</span>
          </h1>
          <p className="text-cGray md:text-sm md:text-center ">
            EatLy help you set saving goals, earn cash back offers, Go to
            disclaimer for more details and get paychecks up to two days early.
            Get a $20 bonus.
          </p>
          <button className="bg-customColor text-white px-6 py-3   rounded-2xl w-fit">
            Get started
          </button>
        </div>
        <div className="flex w-[50%] md:w-full max-h-[80vh] p-12">
          <Image src={image} alt="Image1" className="w-[100%]  object-contain" />
        </div>
      </div>
    </section>
  );
}

export default Intro;
