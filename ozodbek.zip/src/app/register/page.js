"use client"
import React, { useState } from "react";
import { Logo } from "../icons/icons";
import Link from "next/link";
import Image from "next/image";
import image from "../assets/loginImage.png";
import { useRouter } from "next/navigation";
import axios from "axios";
function Login() {
    const router = useRouter();
    const [form, setform] = useState({});
    const handlechange = (e) => {
      setform((pre) => ({
        ...form,
        [e.target.name]: e.target.value,
      }));
    };
    console.log(form);
    const handleSubmit = (e) => {
      e.preventDefault();
  
      axios.post("http://207.154.221.44:4002/api/register", form).then((e) => {
        window.localStorage.setItem("token", JSON.stringify(e.data.data)),
          router.push("/");
      }).catch(err =>{
        alert(err.response.data.message)
      });
    };
  return (
    <main className="fixed  z-50 top-0 left-0 right-0 w-full h-full bg-gradient-to-r from-white from-50% to-50% to-customColor md:to-white ">
      <section className="container flex ">
        <div className="flex h-[100vh]  flex-col justify-between w-1/2 md:w-full py-4">
          <div className="flex">
            <Logo />
          </div>
          <form  onSubmit={handleSubmit} className="flex flex-col relative max-w-md mx-auto p-4 rounded-lg gap-7 md:gap-3  ">
            <h1 className="text-3xl font-semibold w-[250px] text-center m-15 ">
              Sign Up To eatly
            </h1>
            <input onChange={handlechange}
              className="px-5 py-2 rounded-lg bg-[#F5F5F5] outline-none "
              placeholder="Name"
              type="text"
              name="name"
            />
            <input onChange={handlechange}
              className="px-5 py-2 rounded-lg bg-[#F5F5F5] outline-none "
              placeholder="Email"
              type="mail"
              name="email"
            />
            <input onChange={handlechange}
              className="px-5 py-2 rounded-lg bg-[#F5F5F5] outline-none "
              placeholder="Password"
              type="password"
              name="password"
            />
            <button
              className="bg-customColor text-white px-6 py-3   rounded-2xl "
              type="submit"
            >
              SIGH UP
            </button>
            <span className=" text-xs  block mx-auto">
            Already Have An Account?{" "}
              <Link
                className="text-customColor font-semibold"
                href={"/login"}
              >
                Log in
              </Link>
            </span>
          </form>
          <div className="flex items-center justify-between mr-6 md:pr-0">
            <span className="text-cGray">Privasy Police </span>
            <span className="text-cGray">Copyright 2022 </span>
          </div>
        </div>
        <div className="flex w-1/2 md:hidden bg-customColor flex-col  items-center justify-center  h-[100vh]">
            <Image alt="img24" className=" max-w-[60%] " src={image} />
          <div className="flex flex-col">
          <h1 className="text-white text-4xl mx-auto  " >Find Foods With Love </h1>
          <p className="text-white text-md max-w-[550px] text-center mx-auto " >
            Eatly Is The Food Delivery Dashboard And Having More Than 2K+ Dishes
            Including Asian, Chinese, Italians And Many More. Our Dashboard
            Helps You To Manage Orders And Money.
          </p>
          </div>
        </div>
      </section>
    </main>
  );
}

export default Login;
